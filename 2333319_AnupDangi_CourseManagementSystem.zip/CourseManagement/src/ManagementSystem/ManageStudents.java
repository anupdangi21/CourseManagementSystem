package ManagementSystem;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;

public class ManageStudents extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField stu_id;
	private JTextField stu_name;
	private JPasswordField stud_password;
	private JTextField sem;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ManageStudents frame = new ManageStudents();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ManageStudents() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 672, 366);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(35, 103, 133));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Managing Students");
		lblNewLabel.setFont(new Font("Arial", Font.PLAIN, 14));
		lblNewLabel.setBounds(10, 10, 153, 40);
		contentPane.add(lblNewLabel);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(54, 170, 186));
		panel.setBounds(10, 44, 624, 239);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("StudentID:");
		lblNewLabel_1.setFont(new Font("Arial", Font.PLAIN, 14));
		lblNewLabel_1.setBounds(9, 20, 88, 30);
		panel.add(lblNewLabel_1);
		
		stu_id = new JTextField();
		stu_id.setBounds(107, 20, 175, 30);
		panel.add(stu_id);
		stu_id.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("StudentName:");
		lblNewLabel_2.setFont(new Font("Arial", Font.PLAIN, 14));
		lblNewLabel_2.setBounds(10, 60, 109, 30);
		panel.add(lblNewLabel_2);
		
		stu_name = new JTextField();
		stu_name.setBounds(106, 60, 176, 30);
		panel.add(stu_name);
		stu_name.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("Level:");
		lblNewLabel_3.setFont(new Font("Arial", Font.PLAIN, 14));
		lblNewLabel_3.setBounds(292, 178, 45, 30);
		panel.add(lblNewLabel_3);
		
		JComboBox comboBox_modules = new JComboBox();
		comboBox_modules.setBounds(107, 139, 175, 30);
		panel.add(comboBox_modules);
		
		sem = new JTextField();
		sem.setFont(new Font("Arial", Font.PLAIN, 14));
		sem.setBounds(362, 142, 88, 25);
		panel.add(sem);
		sem.setColumns(10);
		
		JComboBox comboBox_level = new JComboBox();
		comboBox_level.setFont(new Font("Arial", Font.PLAIN, 14));
		comboBox_level.setBounds(347, 181, 39, 27);

		comboBox_level.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3", "4", "5", "6"}));
		comboBox_level.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        // Clear existing items in Module_Info
		        comboBox_modules.removeAllItems();

		        // Get the selected level
		        String selectedLevel = comboBox_level.getSelectedItem().toString();

		        if ("4".equals(selectedLevel)) {
		            // Level 4 modules
		            String[] level4Modules = {
		                    "Academic Skills and Team Based Learning",
		                    "Introductory Programming and Problem Solving",
		                    "Fundamentals of Computing",
		                    "Embedded System Programming",
		                    "Internet Software Architecture",
		                    "Computational Mathematics",
		            };
		            for (String module : level4Modules) {
		            	comboBox_modules.addItem(module);
		            }
		        }if ("5".equals(selectedLevel)) {
		            // Level 5 modules
		            String[] level5Modules = {
		            		"Al",
			                "oop", 
			                "nmc",
			                "cloud computing", 
			                "Collaborative Development", 
			                "Human Computer Interaction",
		            };
		            for (String module : level5Modules) {
		            	comboBox_modules.addItem(module);
		            }
		        }if ("6".equals(selectedLevel)) {
		        	String[] level6Modules = {
		        			"Complex Systems",
		        			"High Performance Computing",
		        			"Project and Professionalism",
		        			"Artificial Intelligence and Machine Learning",
		        			"Big Data","\n"
		        };
		        	for(String module : level6Modules) {
		        		comboBox_modules.addItem(module);
		        	}
		    }
		    }
		});
		panel.add(comboBox_level);
		
		JLabel lblNewLabel_4 = new JLabel("Course:");
		lblNewLabel_4.setFont(new Font("Arial", Font.PLAIN, 14));
		lblNewLabel_4.setBounds(9, 100, 57, 23);
		panel.add(lblNewLabel_4);
		
		JComboBox comboBox_c = new JComboBox();
		comboBox_c.setModel(new DefaultComboBoxModel(new String[] {"", "BSc(Hons) in Computer Science", "bibm"}));
		comboBox_c.setBounds(107, 100, 175, 30);
		panel.add(comboBox_c);
		
		stud_password = new JPasswordField();
		stud_password.setBounds(107, 180, 175, 30);
		panel.add(stud_password);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(54, 170, 186));
		panel_1.setBounds(460, 0, 164, 239);
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		JButton btn_add = new JButton("ADD");
		btn_add.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        String studentId = stu_id.getText();
		        String studentName = stu_name.getText();
		        String course = comboBox_c.getSelectedItem().toString();
		        String modules = comboBox_modules.getSelectedItem().toString();
		        String password = new String(stud_password.getPassword());
		        String level = comboBox_level.getSelectedItem().toString();
		        String year= sem.getText();

		        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/coursemanagement", "root", "")) {
		            // Check if the student with the given studentId already exists
		            PreparedStatement checkIfExists = conn.prepareStatement("SELECT * FROM student WHERE studentId = ?");
		            checkIfExists.setString(1, studentId);
		            ResultSet resultSet = checkIfExists.executeQuery();

		            if (resultSet.next()) {
		                // Student with the given studentId already exists
		                JOptionPane.showMessageDialog(null, "Student with this ID already exists. Choose a different ID.");
		            } else {
		            	for (int i = 0; i < comboBox_modules.getItemCount(); i++) {
			                String module = comboBox_modules.getItemAt(i).toString();
		                // Insert the new student data
		                PreparedStatement ps = conn.prepareStatement("INSERT INTO student (studentId, studentName, course, module, password, level, year) VALUES (?, ?, ?, ?, ?, ?, ?)");
		                ps.setString(1, studentId);
		                ps.setString(2, studentName);
		                ps.setString(3, course);
		                ps.setString(4, module);
		                ps.setString(5, password);
		                ps.setString(6, level);
		                ps.setString(7, year);

		                int z = ps.executeUpdate();
		                if (z > 0)
		                    JOptionPane.showMessageDialog(null, "Student Registered successfully...!");
		                else
		                    JOptionPane.showMessageDialog(null, "Error");
		            	}
		            }
		        } catch (SQLException ex) {
		            ex.printStackTrace();
		        }
		    }
		});
		btn_add.setFont(new Font("Arial", Font.PLAIN, 14));
		btn_add.setBounds(10, 10, 144, 33);
		panel_1.add(btn_add);

		
		JButton btn_delete = new JButton("DELETE");
		btn_delete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
		        String teacherIdToDelete = stu_id.getText();

		        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/coursemanagement", "root", "")) {
		            // Check if the teacher data exists
		            PreparedStatement checkIfExists = conn.prepareStatement("SELECT * FROM student WHERE studentId = ?");
		            checkIfExists.setString(1, teacherIdToDelete);
		            ResultSet resultSet = checkIfExists.executeQuery();

		            if (resultSet.next()) {
		                // Teacher data exists, proceed with deletion
		                PreparedStatement ps = conn.prepareStatement("DELETE FROM student WHERE studentId = ?");
		                ps.setString(1, teacherIdToDelete);

		                int rowsAffected = ps.executeUpdate();
		                if (rowsAffected > 0) {
		                    JOptionPane.showMessageDialog(null, "Student Deleted successfully!");
		                } else {
		                    JOptionPane.showMessageDialog(null, "Error occurred while deleting student.");
		                }
		            } else {
		                // Teacher data doesn't exist
		                JOptionPane.showMessageDialog(null, "student not found");
		            }
		        } catch (SQLException ex) {
		            ex.printStackTrace();
		        }
		    }
		});
		btn_delete.setFont(new Font("Arial", Font.PLAIN, 14));
		btn_delete.setBounds(10, 53, 144, 33);
		panel_1.add(btn_delete);
		
		
		JLabel lblNewLabel_5 = new JLabel("Modules:");
		lblNewLabel_5.setFont(new Font("Arial", Font.PLAIN, 14));
		lblNewLabel_5.setBounds(9, 135, 88, 30);
		panel.add(lblNewLabel_5);
		
		JLabel stu = new JLabel("Password:");
		stu.setFont(new Font("Arial", Font.PLAIN, 14));
		stu.setBounds(9, 178, 76, 30);
		panel.add(stu);
		
		JLabel lblNewLabel_6 = new JLabel("Year:");
		lblNewLabel_6.setFont(new Font("Arial", Font.PLAIN, 14));
		lblNewLabel_6.setBounds(292, 139, 66, 29);
		panel.add(lblNewLabel_6);
		
		
		
		JButton btn_back = new JButton("<-Back");
		btn_back.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Administration admin = new Administration();
				admin.setVisible(true);
				dispose();
			}
		});
		btn_back.setFont(new Font("Arial", Font.PLAIN, 14));
		btn_back.setBounds(10, 286, 85, 33);
		contentPane.add(btn_back);
		
		JButton btn_logout = new JButton("Logout");
		btn_logout.setIcon(new ImageIcon("C:\\Users\\Acer\\eclipse-workspace\\CourseManagement\\RequiredImages\\logout.png"));
		btn_logout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Main home = new Main();
				home.setVisible(true);
				dispose();
			}
		});
		btn_logout.setFont(new Font("Arial", Font.PLAIN, 14));
		btn_logout.setBounds(507, 286, 127, 33);
		contentPane.add(btn_logout);
	}
}
