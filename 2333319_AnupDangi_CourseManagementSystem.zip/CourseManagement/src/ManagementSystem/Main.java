//USERNAME:AnupDangi

//wlvid:2333319
//this is the main method file
package ManagementSystem; 
import java.awt.EventQueue;


import java.awt.Image;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;


import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Color;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;

public class Main extends JFrame {
	//data hiding method
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField username_login;
	private JPasswordField passwordField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Main frame = new Main() ;
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
public Main() {

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 800, 500);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(35, 103, 133));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		username_login = new JTextField();
		username_login.setBounds(560, 147, 174, 33);
		contentPane.add(username_login);
		username_login.setColumns(10);

		passwordField = new JPasswordField();
		passwordField.setBounds(560, 203, 174, 33);
		contentPane.add(passwordField);

		JComboBox comboBox = new JComboBox();
		comboBox.setBounds(560, 263, 174, 33);
		comboBox.setFont(new Font("Arial", Font.PLAIN, 14));
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"STUDENT", "TEACHER", "ADMINISTRATION"}));
		contentPane.add(comboBox);

		JLabel welcome = new JLabel("WELCOME BACK!");
		welcome.setBounds(29, 25, 137, 33);
		welcome.setFont(new Font("Arial", Font.BOLD, 15));
		contentPane.add(welcome);

		JPanel panel_image = new JPanel();
		panel_image.setBackground(new Color(54, 170, 186));
		panel_image.setBounds(10, 104, 361, 319);
		contentPane.add(panel_image);
		panel_image.setLayout(null);
		
		JLabel img_main = new JLabel("");
		img_main.setBackground(new Color(54, 170, 186));
		img_main.setBounds(0, 0, 361, 309);
		img_main.setIcon(new ImageIcon("C:\\Users\\Acer\\eclipse-workspace\\CourseManagement\\RequiredImages\\main.png"));
		panel_image.add(img_main);

		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(54, 170, 186));
		panel_1.setBounds(370, 87, 395, 336);
		contentPane.add(panel_1);
		panel_1.setLayout(null);

		JLabel username = new JLabel("USERNAME:-");
		username.setBounds(10, 59, 137, 33);
		username.setIcon(new ImageIcon("C:\\Users\\Acer\\eclipse-workspace\\CourseManagement\\RequiredImages\\name.png"));
		panel_1.add(username);
		username.setBackground(new Color(255, 255, 255));
		username.setFont(new Font("Arial", Font.BOLD, 14));

		JLabel lblNewLabel_1 = new JLabel("PASSWORD:-");
		lblNewLabel_1.setBounds(10, 117, 137, 33);
		lblNewLabel_1.setIcon(new ImageIcon("C:\\Users\\Acer\\eclipse-workspace\\CourseManagement\\RequiredImages\\password.png"));
		panel_1.add(lblNewLabel_1);
		lblNewLabel_1.setFont(new Font("Arial", Font.BOLD, 14));

		JLabel roles = new JLabel("ROLES");
		roles.setBounds(10, 175, 102, 33);
		roles.setIcon(new ImageIcon("C:\\Users\\Acer\\eclipse-workspace\\CourseManagement\\RequiredImages\\roles.png"));
		panel_1.add(roles);
		roles.setFont(new Font("Arial", Font.BOLD, 14));

		JButton register = new JButton("REGISTER NOW");
		register.setIcon(new ImageIcon("C:\\Users\\Acer\\eclipse-workspace\\CourseManagement\\RequiredImages\\registration.png"));
		register.setBackground(new Color(255, 255, 255));
		register.setHorizontalAlignment(SwingConstants.RIGHT);
		register.setBounds(43, 232, 191, 50);
		panel_1.add(register);
		register.setFont(new Font("Arial", Font.BOLD, 15));

		// Update the action listener for the REGISTER NOW button
			register.addActionListener(new ActionListener() {
			    public void actionPerformed(ActionEvent e) {
			        String USERNAME = username_login.getText();
			        String password = new String(passwordField.getPassword());
			        String role = comboBox.getSelectedItem().toString();

			        // Check if the role is "teacher"
			        if ("teacher".equalsIgnoreCase(role)) {
			            JOptionPane.showMessageDialog(null, "Error: Cannot register as a teacher directly. Contact administration.");
			            return; // Exit the actionPerformed method to prevent further execution
			        }

			        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/coursemanagement", "root", "")) {
			            PreparedStatement ps = conn.prepareStatement("INSERT INTO it (USERNAME, PASSWORD, ROLES) VALUES (?, ?, ?)");
			            ps.setString(1, USERNAME);
			            ps.setString(2, password);
			            ps.setString(3, role);

			            int z = ps.executeUpdate();
			            if (z > 0)
			                JOptionPane.showMessageDialog(null, "Registered successfully...!");
			            else
			                JOptionPane.showMessageDialog(null, "Error");
			        } catch (SQLException ex) {
			            ex.printStackTrace();
			        }
			    }
			});

		register.setFont(new Font("Arial", Font.PLAIN, 14));
		
		
		JButton login = new JButton("login");
		login.setIcon(new ImageIcon("C:\\Users\\Acer\\eclipse-workspace\\CourseManagement\\RequiredImages\\Login.png"));
		login.setBackground(new Color(255, 255, 255));
		login.setHorizontalAlignment(SwingConstants.LEFT);
		login.setBounds(243, 232, 125, 50);
		panel_1.add(login);
		login.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			    String USERNAME = username_login.getText();
			    String password = new String(passwordField.getPassword());
			    String role = comboBox.getSelectedItem().toString();

			    try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/coursemanagement", "root", "")) {
			        String query;

			        if ("STUDENT".equalsIgnoreCase(role)) {
			            // Combine the queries for both tables using UNION
			            query = "SELECT studentId AS USERNAME, password FROM student WHERE studentId = ? AND password = ? "
			                    + "UNION "
			                    + "SELECT USERNAME, PASSWORD FROM it WHERE USERNAME = ? AND PASSWORD = ? AND ROLES = ?";
			        } else if ("TEACHER".equalsIgnoreCase(role)) {
			            // Query for the teacher table
			            query = "SELECT TeacherID as USERNAME, password FROM teacher WHERE TeacherID = ? AND password = ?";
			        } else {
			            // Query for other roles in the it table
			            query = "SELECT * FROM it WHERE USERNAME = ? AND PASSWORD = ? AND ROLES = ?";
			        }

			        try (PreparedStatement ps = conn.prepareStatement(query)) {
			            if ("STUDENT".equalsIgnoreCase(role)) {
			                // Set parameters for the student query
			                ps.setString(1, USERNAME);
			                ps.setString(2, password);
			                ps.setString(3, USERNAME);
			                ps.setString(4, password);
			                ps.setString(5, role);
			            } else if ("TEACHER".equalsIgnoreCase(role)) {
			                // Set parameters for the teacher query
			                ps.setString(1, USERNAME);
			                ps.setString(2, password);
			            } else {
			                // Set parameters for other queries
			                ps.setString(1, USERNAME);
			                ps.setString(2, password);
			                ps.setString(3, role);
			            }

			            ResultSet rs = ps.executeQuery();
			            if (rs.next()) {
			                // Login successful
			                if ("STUDENT".equals(role.toUpperCase())) {
			                    HomeStudent homeStudent = new HomeStudent();
			                    homeStudent.setVisible(true);
			                    dispose(); // Closing the current frame
			                } else if ("TEACHER".equals(role.toUpperCase())) {
			                    HomeTeacher homeTeacher = new HomeTeacher();
			                    homeTeacher.setVisible(true);
			                    dispose(); // Closing the current frame
			                } else if ("ADMINISTRATION".equals(role.toUpperCase())) {
			                    Administration adminHome = new Administration();
			                    adminHome.setVisible(true);
			                    dispose(); // Closing the current frame
			                } else {
			                    // Handling error if the user inputs an invalid role
			                    JOptionPane.showMessageDialog(null, "Invalid inputs. Please enter correct credentials");
			                }
			            } else {
			                // Handling error if the whole input did not match
			                JOptionPane.showMessageDialog(null, "Username and password did not match");
			            }
			        }
			    } catch (SQLException ex) {
			        ex.printStackTrace();
			    }
			}
		});

				

		login.setFont(new Font("Arial", Font.BOLD, 15));
		

		JPanel panel_2 = new JPanel();
		panel_2.setBackground(new Color(54, 170, 189));
		panel_2.setBounds(10, 10, 755, 95);
		contentPane.add(panel_2);
		panel_2.setLayout(null);

		JLabel Img_hat = new JLabel("");
		Img_hat.setFont(new Font("Arial", Font.PLAIN, 16));
		Img_hat.setBounds(534, 10, 108, 75);
		Img_hat.setIcon(new ImageIcon("C:\\Users\\Acer\\eclipse-workspace\\CourseManagement\\RequiredImages\\hat.png"));
		panel_2.add(Img_hat);

		JLabel cms = new JLabel("Course Management System");
		cms.setBounds(280, 23, 320, 45);
		panel_2.add(cms);
		cms.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 18));

	}
}





