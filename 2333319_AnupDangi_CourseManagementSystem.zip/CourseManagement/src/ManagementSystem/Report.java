package ManagementSystem;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JButton;
import java.awt.Color;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class Report extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField id_stud;
	private JTextField std_name;
	private JTextField std_level;
	private JTextField result_set;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Report frame = new Report();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Report() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 637, 517);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(35, 103, 133));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Final Report:");
		lblNewLabel.setFont(new Font("Arial", Font.BOLD, 18));
		lblNewLabel.setBounds(10, 23, 142, 46);
		contentPane.add(lblNewLabel);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(54, 170, 186));
		panel.setBounds(10, 64, 593, 361);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(54, 170, 186));
		panel_1.setBounds(23, 94, 524, 227);
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		std_level = new JTextField();
		std_level.setBounds(378, 16, 50, 31);
		std_level.setEditable(false);
		panel_1.add(std_level);
		std_level.setColumns(10);
		
		
		JLabel lblNewLabel_1 = new JLabel("Enter Student ID:");
		lblNewLabel_1.setFont(new Font("Arial", Font.PLAIN, 14));
		lblNewLabel_1.setBounds(119, 30, 121, 35);
		panel.add(lblNewLabel_1);
		
		result_set = new JTextField();
		result_set.setBounds(63, 80, 365, 41);
		result_set.setEditable(false);
		panel_1.add(result_set);
		result_set.setColumns(10);
		
		id_stud = new JTextField();
		id_stud.setBounds(231, 31, 133, 35);
		panel.add(id_stud);
		id_stud.setColumns(10);
		
		//"SELECT studentName, level, course, module FROM student WHERE studentId = "+t1.getText()+";";
		
		JButton btn_search = new JButton("Search");
		btn_search.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			    try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/coursemanagement", "root", "")) {
			        // Prepare the SQL statement to check if the student ID exists
			        String query = "SELECT studentName, level FROM student WHERE studentId = ?";
			        try (PreparedStatement ps = conn.prepareStatement(query)) {
			            ps.setString(1, id_stud.getText());

			            ResultSet rs = ps.executeQuery();

			            // Inside the ActionListener for the search button
			            if (rs.next()) {
			                // Student ID exists, display the information
			                String studentName = rs.getString("studentName");
			                String level = rs.getString("level");

			                // Populate the fields with the retrieved information
			                std_name.setText(studentName);
			                std_level.setText(level);

			                // Now, query the "marks" table to get the marks for the student
			                String marksQuery = "SELECT marks FROM marks WHERE studentId = ?";
			                try (PreparedStatement marksPs = conn.prepareStatement(marksQuery)) {
			                    marksPs.setString(1, id_stud.getText());

			                    ResultSet marksRs = marksPs.executeQuery();

			                    if (marksRs.next()) {
			                        int marks = marksRs.getInt("marks");

			                        // Display the result in the result_set JTextField
			                        if (marks < 40) {
			                            result_set.setText("Fail - Not eligible for the next semester.");
			                        } else {
			                            result_set.setText("Pass - Eligible for the next semester.");
			                        }
			                    } else {
			                        // No marks found for the student
			                        result_set.setText("Marks not found for the student.");
			                    }
			                } catch (SQLException marksEx) {
			                    marksEx.printStackTrace();
			                }

			            } else {
			                // Student ID does not exist
			                JOptionPane.showMessageDialog(null, "Student ID not found.");

			                // Clear all fields if student ID is not found
			                std_name.setText("");
			                std_level.setText("");
			                result_set.setText(""); // Clear the result_set field
			            }
			        } catch (SQLException ex) {
			            ex.printStackTrace();
			        }
			    } catch (SQLException ex) {
			        ex.printStackTrace();
			    }
			}
		});


		btn_search.setFont(new Font("Arial", Font.PLAIN, 12));
		btn_search.setBounds(374, 37, 85, 23);
		panel.add(btn_search);
		
		
		
		JLabel lblNewLabel_2 = new JLabel("StudentName:");
		lblNewLabel_2.setFont(new Font("Arial", Font.PLAIN, 14));
		lblNewLabel_2.setBounds(10, 10, 105, 41);
		panel_1.add(lblNewLabel_2);
		
		std_name = new JTextField();
		std_name.setBounds(109, 16, 187, 31);
		std_name.setEditable(false);
		panel_1.add(std_name);
		std_name.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("Level:");
		lblNewLabel_3.setFont(new Font("Arial", Font.PLAIN, 14));
		lblNewLabel_3.setBounds(322, 16, 44, 28);
		panel_1.add(lblNewLabel_3);
		
		
		
		
		JButton btnNewButton = new JButton("Back");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Administration admin = new Administration();
				admin.setVisible(true);
				dispose();
			}
		});
		btnNewButton.setFont(new Font("Arial", Font.PLAIN, 14));
		btnNewButton.setBounds(10, 435, 85, 35);
		contentPane.add(btnNewButton);
	}
}
