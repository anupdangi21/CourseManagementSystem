package ManagementSystem;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;

public class ManageTeacher extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField teacher_id;
	private JTextField teacher_name;
	private JTextField module;
	private JPasswordField teacher_password;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ManageTeacher frame = new ManageTeacher();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ManageTeacher() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 628, 499);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(35, 103, 133));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Managing Teacher");
		lblNewLabel.setFont(new Font("Arial", Font.BOLD, 14));
		lblNewLabel.setBounds(10, 10, 150, 31);
		contentPane.add(lblNewLabel);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(54, 170, 186));
		panel.setBounds(10, 40, 558, 324);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("Teacher ID:");
		lblNewLabel_1.setFont(new Font("Arial", Font.PLAIN, 14));
		lblNewLabel_1.setBounds(10, 20, 96, 32);
		panel.add(lblNewLabel_1);
		
		teacher_id = new JTextField();
		teacher_id.setBounds(116, 22, 144, 32);
		panel.add(teacher_id);
		teacher_id.setColumns(10);
		
		JLabel Teacher_name = new JLabel("Teacher Name:");
		Teacher_name.setFont(new Font("Arial", Font.PLAIN, 14));
		Teacher_name.setBounds(10, 72, 106, 32);
		panel.add(Teacher_name);
		
		teacher_name = new JTextField();
		teacher_name.setBounds(116, 74, 144, 32);
		panel.add(teacher_name);
		teacher_name.setColumns(10);
		
		JButton btnNewButton_1 = new JButton("ADD");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String teacherId = teacher_id.getText();
				String teachername=teacher_name.getText();
				String Course=module.getText();
				String password = new String(teacher_password.getPassword());

				try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/coursemanagement", "root","")) {
					PreparedStatement ps = conn.prepareStatement("INSERT INTO teacher (TeacherID, TeacherName,module, Password) VALUES (?, ?, ?, ?)");					
					ps.setString(1, teacherId);
					ps.setString(2, teachername);
					ps.setString(3, Course);
					ps.setString(4, password);

					int z = ps.executeUpdate();
					if (z > 0)
						JOptionPane.showMessageDialog(null, "Teacher Registered sucessfully...!");
					else
						JOptionPane.showMessageDialog(null, "Error");
				
			}catch (SQLException ex) {
				ex.printStackTrace();
			}
			}
		});
		btnNewButton_1.setFont(new Font("Arial", Font.PLAIN, 14));
		btnNewButton_1.setBounds(10, 261, 84, 39);
		panel.add(btnNewButton_1);
		
		JButton btnDelete = new JButton("DELETE");
		btnDelete.setFont(new Font("Arial", Font.PLAIN, 14));
		btnDelete.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        String teacherIdToDelete = teacher_id.getText();

		        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/coursemanagement", "root", "")) {
		            // Check if the teacher data exists
		            PreparedStatement checkIfExists = conn.prepareStatement("SELECT * FROM teacher WHERE TeacherID = ?");
		            checkIfExists.setString(1, teacherIdToDelete);
		            ResultSet resultSet = checkIfExists.executeQuery();

		            if (resultSet.next()) {
		                // Teacher data exists, proceed with deletion
		                PreparedStatement ps = conn.prepareStatement("DELETE FROM teacher WHERE TeacherID = ?");
		                ps.setString(1, teacherIdToDelete);

		                int rowsAffected = ps.executeUpdate();
		                if (rowsAffected > 0) {
		                    JOptionPane.showMessageDialog(null, "Teacher deleted successfully!");
		                } else {
		                    JOptionPane.showMessageDialog(null, "Error occurred while deleting teacher.");
		                }
		            } else {
		                // Teacher data doesn't exist
		                JOptionPane.showMessageDialog(null, "Teacher not found");
		            }
		        } catch (SQLException ex) {
		            ex.printStackTrace();
		        }
		    }
		});

		btnDelete.setBounds(452, 259, 96, 42);
		panel.add(btnDelete);
		
		JLabel lblNewLabel_2 = new JLabel("Module:");
		lblNewLabel_2.setFont(new Font("Arial", Font.PLAIN, 14));
		lblNewLabel_2.setBounds(10, 176, 96, 32);
		panel.add(lblNewLabel_2);
		
		module = new JTextField();
		module.setBounds(116, 178, 144, 32);
		panel.add(module);
		module.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("Password:");
		lblNewLabel_3.setFont(new Font("Arial", Font.PLAIN, 14));
		lblNewLabel_3.setBounds(10, 127, 96, 32);
		panel.add(lblNewLabel_3);
		
		teacher_password = new JPasswordField();
		teacher_password.setBounds(116, 129, 144, 32);
		panel.add(teacher_password);
		
		
		
		JButton btn_logout = new JButton("Logout");
		btn_logout.setIcon(new ImageIcon("C:\\Users\\Acer\\eclipse-workspace\\CourseManagement\\RequiredImages\\logout.png"));
		btn_logout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Main home= new Main();
				home.setVisible(true);
			}
		});
		btn_logout.setFont(new Font("Arial", Font.PLAIN, 16));
		btn_logout.setBounds(441, 389, 127, 40);
		contentPane.add(btn_logout);
		
		JButton btnNewButton = new JButton("Return");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Administration admin = new Administration();
				admin.setVisible(true);
				dispose();
			}
		});
		btnNewButton.setFont(new Font("Arial", Font.PLAIN, 14));
		btnNewButton.setBounds(21, 390, 91, 40);
		contentPane.add(btnNewButton);
	}
}
