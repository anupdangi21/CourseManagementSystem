//Name:AnupDangi
// id:2333319
package ManagementSystem;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Color;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;

public class HomeStudent extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField displayCourse;
	private JTextField displayTeacher;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					HomeStudent frame = new HomeStudent();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public HomeStudent() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 800, 500);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(35, 103, 133));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(54, 170, 186));
		panel.setBounds(29, 61, 735, 332);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(10, 10, 161, 312);
		panel_1.setBackground(new Color(112, 205, 201));
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		JButton enrollment = new JButton("Enroll into\r\n new course");
		enrollment.setBounds(10, 140, 137, 40);
		panel_1.add(enrollment);
		enrollment.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Enrollment enrollFrame = new Enrollment(); //directing into enrollment
                enrollFrame.setVisible(true);
               dispose();
            }
        });
		enrollment.setBackground(new Color(159, 190, 65));
		enrollment.setFont(new Font("Arial", Font.PLAIN, 14));
		
		JButton viewTeacher = new JButton("View Teachers");
		viewTeacher.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ViewTeacher teacher= new ViewTeacher();
				teacher.setVisible(true);
				dispose();
			}
		});
		viewTeacher.setBounds(10, 201, 137, 40);
		panel_1.add(viewTeacher);
		viewTeacher.setBackground(new Color(159, 190, 65));
		viewTeacher.setFont(new Font("Arial", Font.PLAIN, 14));
		
		JButton seeResult = new JButton("See Results");
		seeResult.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SeeResult result = new SeeResult();
				result.setVisible(true);
				dispose();
			}
		});
		seeResult.setBounds(10, 262, 137, 40);
		panel_1.add(seeResult);
		seeResult.setBackground(new Color(159, 190, 65));
		seeResult.setFont(new Font("Arial", Font.PLAIN, 14));
		
		JPanel panel_4 = new JPanel();
		panel_4.setBounds(10, 10, 137, 120);
		panel_4.setBackground(new Color(112, 205, 201));
		panel_1.add(panel_4);
		panel_4.setLayout(null);
		
		JLabel img_home = new JLabel("");
		img_home.setBackground(new Color(0, 0, 0));
		img_home.setBounds(0, 0, 133, 120);
		img_home.setIcon(new ImageIcon("C:\\Users\\Acer\\eclipse-workspace\\CourseManagement\\RequiredImages\\home.png"));
		panel_4.add(img_home);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBounds(174, 10, 151, 70);
		panel_2.setBackground(new Color(112, 205, 201));
		panel.add(panel_2);
		panel_2.setLayout(null);
		
		JLabel totalCourse = new JLabel("Total modules");
		totalCourse.setFont(new Font("Arial", Font.PLAIN, 14));
		totalCourse.setBounds(10, 10, 131, 27);
		panel_2.add(totalCourse);
		
		displayCourse = new JTextField();
		displayCourse.setBounds(10, 39, 49, 21);
		panel_2.add(displayCourse);
		displayCourse.setEditable(false);

		try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/coursemanagement", "root", "")) {
		    String query = "SELECT COUNT(module) FROM student";
		    try (PreparedStatement ps = conn.prepareStatement(query);
		         ResultSet rs = ps.executeQuery()) {

		        // Check if there is a result
		        if (rs.next()) {
		            // Get the count from the result set
		            int totalCount = rs.getInt(1);

		            // Display the total count in the JTextField
		            displayCourse.setText(String.valueOf(totalCount));
		        } else {
		            // Handle the case where there is no result (optional)
		            displayCourse.setText(": 0");
		        }
		    }
		} catch (SQLException ex) {
		    ex.printStackTrace();
		}

		displayCourse.setFont(new Font("Arial", Font.PLAIN, 14));
		displayCourse.setColumns(10);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBounds(337, 10, 154, 70);
		panel_3.setBackground(new Color(112, 205, 201));
		panel.add(panel_3);
		panel_3.setLayout(null);
		
		JLabel totalTeachers = new JLabel("Total no. of teachers");
		totalTeachers.setFont(new Font("Arial", Font.PLAIN, 14));
		
		totalTeachers.setBounds(10, 10, 138, 26);
		panel_3.add(totalTeachers);
		
		displayTeacher = new JTextField();
		displayTeacher.setBounds(10, 39, 46, 26);
		displayTeacher.setEditable(false);
		try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/coursemanagement", "root", "")) {
		    // Execute SQL query to get the count of rows in 'bsc_hons' table
		    String query = "SELECT COUNT(*) FROM teacher";
		    try (PreparedStatement ps = conn.prepareStatement(query);
		         ResultSet rs = ps.executeQuery()) {

		        // Check if there is a result
		        if (rs.next()) {
		            // Get the count from the result set
		            int totalCount = rs.getInt(1);

		            // Display the total count in the JTextField
		            displayTeacher.setText("" + totalCount);
		        } else {
		            // Handle the case where there is no result (optional)
		            displayTeacher.setText(": 0");
		        }
		    }
		} catch (SQLException ex) {
		    ex.printStackTrace();
		}
		panel_3.add(displayTeacher);
		displayTeacher.setColumns(10);
		
		JLabel img_course = new JLabel("New label");
		img_course.setBounds(181, 122, 544, 210);
		img_course.setIcon(new ImageIcon("C:\\Users\\Acer\\eclipse-workspace\\CourseManagement\\RequiredImages\\course.png"));

		panel.add(img_course);
		
		JLabel lblNewLabel = new JLabel("Course We Offer...!");
		lblNewLabel.setBounds(181, 90, 288, 39);
		lblNewLabel.setFont(new Font("Arial", Font.BOLD, 18));
		panel.add(lblNewLabel);
		
		
		JLabel welcomeBack = new JLabel("Welcome back...!");
		welcomeBack.setFont(new Font("Arial", Font.PLAIN, 15));
		welcomeBack.setBounds(29, 22, 137, 29);
		contentPane.add(welcomeBack);
		
		JButton logout = new JButton("Logout");
		logout.setHorizontalAlignment(SwingConstants.LEFT);
		logout.setIcon(new ImageIcon("C:\\Users\\Acer\\eclipse-workspace\\CourseManagement\\RequiredImages\\logout.png"));
        logout.setBackground(new Color(185, 206, 179));
        logout.setFont(new Font("Arial", Font.PLAIN, 15));
        logout.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Ask for confirmation
                int result = JOptionPane.showConfirmDialog(null, "Are you sure you want to logout?", "Logout Confirmation",
                        JOptionPane.YES_NO_OPTION);

                if (result == JOptionPane.YES_OPTION) {
                    Main loginFrame = new Main(); 
                    loginFrame.setVisible(true);
                    dispose(); // Close the current frame (HomeTeacher)
                } else {
                    
                }
            }
        });
		logout.setBounds(29, 403, 137, 33);
		contentPane.add(logout);
		
		JLabel s_p = new JLabel("Student Panel");
		s_p.setFont(new Font("Arial", Font.PLAIN, 15));
		s_p.setBounds(425, 14, 124, 37);
		contentPane.add(s_p);
		
		
	}
}
