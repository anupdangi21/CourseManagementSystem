//Name:AnupDangi
//wlv id:2333319
package ManagementSystem;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Color;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JTable;
import javax.swing.JScrollPane;

public class Administration extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField display_stud;
	private JTextField display_teacher;
	private JTable table_std;
	private JTable table_t;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Administration frame = new Administration();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Administration() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 980, 519);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(35, 103, 133));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(10, 38, 931, 391);
		panel.setBackground(new Color(54, 170, 186));
		contentPane.add(panel);
		panel.setLayout(null);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(112, 205, 201));
		panel_1.setBounds(0, 135, 170, 256);
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		JButton btn_AddCourse = new JButton("Add course");
		btn_AddCourse.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AddCourse addCourse= new AddCourse();
				addCourse.setVisible(true);
			}
		});
		btn_AddCourse.setHorizontalAlignment(SwingConstants.LEFT);
		btn_AddCourse.setBounds(10, 10, 145, 39);
		panel_1.add(btn_AddCourse);
		btn_AddCourse.setFont(new Font("Arial", Font.PLAIN, 14));
		
		JButton btn_ManageS = new JButton("Manage Students");
		btn_ManageS.setHorizontalAlignment(SwingConstants.LEFT);
		btn_ManageS.setBounds(10, 70, 145, 39);
		panel_1.add(btn_ManageS);
		btn_ManageS.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ManageStudents manageStud= new ManageStudents();
				manageStud.setVisible(true);
			}
		});
		btn_ManageS.setFont(new Font("Arial", Font.PLAIN, 14));
		
		JButton btn_manageT = new JButton("Manage Teacher");
		btn_manageT.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ManageTeacher manageTeacher= new ManageTeacher();
				manageTeacher.setVisible(true);
				
			}
		});
		btn_manageT.setHorizontalAlignment(SwingConstants.LEFT);
		btn_manageT.setBounds(10, 129, 145, 39);
		panel_1.add(btn_manageT);
		btn_manageT.setFont(new Font("Arial", Font.PLAIN, 14));
		
		JButton btn_report = new JButton("Generate report");
		btn_report.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Report report = new Report();
				report.setVisible(true);
				dispose();
			}
		});
		btn_report.setHorizontalAlignment(SwingConstants.LEFT);
		btn_report.setFont(new Font("Arial", Font.PLAIN, 14));
		btn_report.setBounds(10, 191, 145, 39);
		panel_1.add(btn_report);
		
		JPanel panel_6 = new JPanel();
		panel_6.setBackground(new Color(112, 205, 202));
		panel_6.setBounds(449, 0, 247, 102);
		panel.add(panel_6);
		panel_6.setLayout(null);
		
		display_stud = new JTextField();
		display_stud.setBounds(121, 39, 58, 37);
		panel_6.add(display_stud);
		display_stud.setEditable(false);
		display_stud.setColumns(10);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(new Color(112, 205, 201));
		panel_2.setBounds(170, 0, 282, 102);
		panel.add(panel_2);
		panel_2.setLayout(null);
		try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/coursemanagement", "root", "")) {
		    // Execute SQL query to get the count of modules in 'enroll_bschons' table
		    String query = "SELECT COUNT(DISTINCT studentid) FROM student;";
		    try (PreparedStatement ps = conn.prepareStatement(query);
		         ResultSet rs = ps.executeQuery()) {

		        // Check if there is a result
		        if (rs.next()) {
		            // Get the count from the result set
		            int totalCount = rs.getInt(1);

		            // Display the total count in the JTextField
		            display_stud.setText(String.valueOf(totalCount));
		        } else {
		            display_stud.setText(": 0");
		        }
		    }
		} catch (SQLException ex) {
		    ex.printStackTrace();
		}
		
		display_teacher = new JTextField();
		display_teacher.setEditable(false);
		display_teacher.setBounds(122, 40, 58, 38);
		try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/coursemanagement", "root", "")) {
		    // Execute SQL query to get the count of rows in 'enroll_bschons' table
		    String query = "SELECT COUNT(*) FROM teacher";
		    try (PreparedStatement ps = conn.prepareStatement(query);
		         ResultSet rs = ps.executeQuery()) {
		        if (rs.next()) {
		            int totalCount = rs.getInt(1);

		            // Display the total count in the JTextField
		            display_teacher.setText(String.valueOf(totalCount));
		        } else {
		            // Handle the case where there is no result (optional)
		            display_teacher.setText(": 0");
		        }
		    }
		} catch (SQLException ex) {
		    ex.printStackTrace();
		}


		panel_2.add(display_teacher);
		display_teacher.setColumns(10);
		
		JLabel Display_Teacher = new JLabel("Overall Teachers");
		Display_Teacher.setBounds(122, 10, 119, 32);
		panel_2.add(Display_Teacher);
		Display_Teacher.setFont(new Font("Arial", Font.PLAIN, 14));
		
		JLabel lbl_teach = new JLabel("");
		lbl_teach.setIcon(new ImageIcon("C:\\Users\\Acer\\eclipse-workspace\\CourseManagement\\RequiredImages\\teacher.png"));

		lbl_teach.setBounds(0, 0, 112, 102);
		panel_2.add(lbl_teach);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBackground(new Color(112, 205, 201));
		panel_3.setBounds(0, 0, 170, 136);
		panel.add(panel_3);
		panel_3.setLayout(null);
		
		JLabel img_home = new JLabel("");
		img_home.setBounds(22, 10, 120, 126);
		img_home.setIcon(new ImageIcon("C:\\Users\\Acer\\eclipse-workspace\\CourseManagement\\RequiredImages\\home.png"));
		panel_3.add(img_home);
		
		JPanel panel_4 = new JPanel();
		panel_4.setBackground(new Color(112, 205, 202));
		panel_4.setBounds(170, 100, 370, 291);
		panel.add(panel_4);
		panel_4.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Showing Overall Students");
		lblNewLabel.setFont(new Font("Arial", Font.PLAIN, 14));
		lblNewLabel.setBounds(10, 10, 166, 32);
		panel_4.add(lblNewLabel);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(0, 40, 360, 251);
		panel_4.add(scrollPane);
		table_std = new JTable();
		scrollPane.setViewportView(table_std);
		try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/coursemanagement", "root", "")) {
            PreparedStatement ps = conn.prepareStatement("SELECT studentId, studentName, course, module, level FROM student;");
            ResultSet rs = ps.executeQuery();
            ResultSetMetaData rsmd = rs.getMetaData();
			DefaultTableModel model = (DefaultTableModel) table_std.getModel();

            int cols = rsmd.getColumnCount();
            String[] colName = new String[cols];

            for (int i = 0; i < cols; i++) {
                colName[i] = rsmd.getColumnName(i + 1);
            }

            model.setColumnIdentifiers(colName);

            String id, name, course, Model, level;
            
            while (rs.next()) {
                id = rs.getString(1);
                name = rs.getString(2);
                course = rs.getString(3);
                Model = rs.getString(4);
                level = rs.getString(5);
                
                String[] row = {id, name, course, Model, level};
                model.addRow(row);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
		
		JPanel panel_5 = new JPanel();
		panel_5.setBackground(new Color(112, 205, 202));
		panel_5.setBounds(539, 100, 382, 291);
		panel.add(panel_5);
		panel_5.setLayout(null);
		
		JLabel lblNewLabel_2 = new JLabel("Showing Overall Teachers");
		lblNewLabel_2.setFont(new Font("Arial", Font.PLAIN, 14));
		lblNewLabel_2.setBounds(10, 10, 194, 33);
		panel_5.add(lblNewLabel_2);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(0, 37, 382, 254);
		panel_5.add(scrollPane_1);
		
		table_t = new JTable();
		scrollPane_1.setViewportView(table_t);
		DefaultTableModel model = (DefaultTableModel) table_t.getModel();
		try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/coursemanagement", "root","")) {
			PreparedStatement ps = conn.prepareStatement("SELECT TeacherID, TeacherName,module FROM teacher;");
			ResultSet rs = ps.executeQuery();
			ResultSetMetaData rsmd=rs.getMetaData();
			int cols = rsmd.getColumnCount();
			String[] colName = new String[cols];
			for (int i = 0; i < cols; i++)
				colName[i] = rsmd.getColumnName(i + 1);
			model.setColumnIdentifiers(colName);
			String id,name, Model;
			while(rs.next()) {
				id=rs.getString(1);
				name=rs.getString(2);
				Model=rs.getString(3);
				String[] row= {id,name,Model};
				model.addRow(row);
				}
			}catch (SQLException ex) {
			ex.printStackTrace();
		}
		
		
		
		JLabel Display_Std = new JLabel("Overall Students");
		Display_Std.setBounds(121, 10, 106, 32);
		panel_6.add(Display_Std);
		Display_Std.setFont(new Font("Arial", Font.PLAIN, 14));
		
		
		
		JLabel lbl_stud = new JLabel("");
		lbl_stud.setIcon(new ImageIcon("C:\\Users\\Acer\\eclipse-workspace\\CourseManagement\\RequiredImages\\student.png"));

		lbl_stud.setBounds(10, 10, 120, 92);
		panel_6.add(lbl_stud);
		
		JPanel panel_7 = new JPanel();
		panel_7.setBackground(new Color(112, 205, 202));
		panel_7.setBounds(697, 0, 224, 102);
		panel.add(panel_7);
		
		JButton btnNewButton = new JButton("logout");
		btnNewButton.setIcon(new ImageIcon("C:\\Users\\Acer\\eclipse-workspace\\CourseManagement\\RequiredImages\\logout.png"));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
                // Ask for confirmation
                int result = JOptionPane.showConfirmDialog(null, "Are you sure you want to logout?", "Logout Confirmation",
                        JOptionPane.YES_NO_OPTION);

                if (result == JOptionPane.YES_OPTION) {
                    Main loginFrame = new Main(); 
                    loginFrame.setVisible(true);
                    dispose(); // Close the current frame (HomeTeacher)
                } else {
                }
            }
        });
		btnNewButton.setBounds(796, 439, 145, 33);
		btnNewButton.setFont(new Font("Arial", Font.PLAIN, 14));
		
		JButton logout = new JButton("Logout");
        logout.setBackground(new Color(185, 206, 179));
        logout.setFont(new Font("Arial", Font.PLAIN, 15));
        logout.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Ask for confirmation
                int result = JOptionPane.showConfirmDialog(null, "Are you sure you want to logout?", "Logout Confirmation",
                        JOptionPane.YES_NO_OPTION);

                if (result == JOptionPane.YES_OPTION) {
                    Main loginFrame = new Main(); 
                    loginFrame.setVisible(true);
                    dispose(); // Close the current frame (HomeTeacher)
                } else {
                }
            }
        });
		contentPane.add(btnNewButton);
		
		JLabel lblNewLabel_1 = new JLabel("Administration panel");
		lblNewLabel_1.setBounds(10, 10, 163, 33);
		lblNewLabel_1.setFont(new Font("Arial", Font.PLAIN, 14));
		contentPane.add(lblNewLabel_1);
		
	}
}
