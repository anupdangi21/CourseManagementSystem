package ManagementSystem;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;

public class MarkStudents extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField stud_id;
	private JTextField std_level;
	private JTextField std_course;
	private JTextField mark;
	private JTextField grade;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MarkStudents frame = new MarkStudents();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MarkStudents() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 674, 523);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(35, 103, 133));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		
		JLabel lblNewLabel = new JLabel("Marking Students");
		lblNewLabel.setFont(new Font("Arial", Font.PLAIN, 14));
		lblNewLabel.setBounds(10, 10, 125, 26);
		contentPane.add(lblNewLabel);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(54, 170, 189));
		panel.setBounds(10, 44, 640, 379);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JTextField std_name = new JTextField();
		std_name.setBounds(77, 136, 145, 34);
		std_name.setEditable(false);
		panel.add(std_name);
		std_name.setColumns(10);
		
		std_level = new JTextField();
		std_level.setBounds(268, 136, 45, 34);
		std_level.setEditable(false);
		panel.add(std_level);
		std_level.setColumns(10);
		
		mark = new JTextField();
		mark.setBounds(410, 212, 45, 35);
		panel.add(mark);
		mark.setColumns(10);
		
		
		grade = new JTextField();
		grade.setBounds(523, 212, 45, 35);
		panel.add(grade);
		grade.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Search student ID");
		lblNewLabel_1.setFont(new Font("Arial", Font.PLAIN, 14));
		lblNewLabel_1.setBounds(106, 70, 116, 28);
		panel.add(lblNewLabel_1);
		
		JComboBox std_module = new JComboBox();
		std_module.setBounds(77, 206, 196, 34);
		panel.add(std_module);
		
		stud_id = new JTextField();
		stud_id.setBounds(241, 69, 129, 34);
		panel.add(stud_id);
		stud_id.setColumns(10);
		
		JButton btnNewButton_1 = new JButton("Set marks");
		btnNewButton_1.setBounds(10, 335, 116, 34);
		btnNewButton_1.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        String studentId = stud_id.getText();
		        String name = std_name.getText();
		        String level = std_level.getText();
		        String course = std_course.getText();
		        String module = std_module.getSelectedItem().toString();
		        String marks = mark.getText();
		        String grades = grade.getText();

		        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/coursemanagement", "root", "")) {
		            // Check if the selected module exists in the teacher table
		            String moduleMatchQuery = "SELECT * FROM teacher";
		            try (PreparedStatement moduleMatchPs = conn.prepareStatement(moduleMatchQuery)) {
		                ResultSet moduleMatchRs = moduleMatchPs.executeQuery();

		                if (moduleMatchRs.next()) {
		                    // Module matches; check if marks are already inserted for this module
		                    String marksExistQuery = "SELECT * FROM marks WHERE modules = ?";
		                    try (PreparedStatement marksExistPs = conn.prepareStatement(marksExistQuery)) {
		                        marksExistPs.setString(1, module);
		                        ResultSet marksExistRs = marksExistPs.executeQuery();

		                        if (marksExistRs.next()) {
		                            // Marks already inserted for the module
		                            JOptionPane.showMessageDialog(null, "Marks already inserted for the selected module.");
		                        } else {
		                            // Proceed with inserting or updating marks
		                            PreparedStatement ps = conn.prepareStatement("INSERT INTO marks (StudentID, studentName, level, course, modules, marks, grade) VALUES (?, ?, ?, ?, ?, ?, ?)");
		                            ps.setString(1, studentId);
		                            ps.setString(2, name);
		                            ps.setString(3, level);
		                            ps.setString(4, course);
		                            ps.setString(5, module);
		                            ps.setString(6, marks);
		                            ps.setString(7, grades);

		                            int z = ps.executeUpdate();
		                            if (z > 0) {
		                                JOptionPane.showMessageDialog(null, "Marks Registered successfully...!");
		                            } else {
		                                JOptionPane.showMessageDialog(null, "Error");
		                            }
		                        }
		                    }
		                } else {
		                    // Module does not match; teacher cannot mark this student
		                    JOptionPane.showMessageDialog(null, "You are not allowed to mark this student in the selected module.");
		                }
		            }
		        } catch (SQLException ex) {
		            ex.printStackTrace();
		        }
		    }
		});


		btnNewButton_1.setFont(new Font("Arial", Font.PLAIN, 14));
		btnNewButton_1.setBounds(10, 335, 116, 34);
		panel.add(btnNewButton_1);
		JButton btnNewButton_2 = new JButton("Update");
		btnNewButton_2.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        String marksToUpdate = mark.getText();
		        String gradeToUpdate = grade.getText();

		        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/coursemanagement", "root", "")) {
		            String updateQuery = "UPDATE marks SET marks = ?, grade = ?";
		            PreparedStatement updateMarks = conn.prepareStatement(updateQuery);

		            // Set parameters
		            updateMarks.setString(1, marksToUpdate);
		            updateMarks.setString(2, gradeToUpdate);

		            int rowsAffected = updateMarks.executeUpdate();

		            if (rowsAffected > 0) {
		                JOptionPane.showMessageDialog(null, "Marks updated successfully!");
		            } else {
		                JOptionPane.showMessageDialog(null, "Error occurred while updating marks.");
		            }

		        } catch (SQLException ex) {
		            ex.printStackTrace();
		        }
		    }
		});

		btnNewButton_2.setFont(new Font("Arial", Font.PLAIN, 14));
		btnNewButton_2.setBounds(505, 335, 106, 34);
		panel.add(btnNewButton_2);
		
		

		JButton btnNewButton_3 = new JButton("Search");
		btnNewButton_3.setFont(new Font("Arial", Font.PLAIN, 14));
		btnNewButton_3.setBounds(380, 68, 85, 33);
		panel.add(btnNewButton_3);
		btnNewButton_3.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {

		        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/coursemanagement", "root", "")) {
		            // Prepare the SQL statement to check if the student ID exists
		            String query = "SELECT * FROM student WHERE studentId = "+stud_id.getText()+";";
		            try (PreparedStatement ps = conn.prepareStatement(query)) {

		                ResultSet rs = ps.executeQuery();

		             // Inside the ActionListener for the search button
		                if (rs.next()) {
		                    // Student ID exists, display the information
		                    String studentName = rs.getString("studentName");
		                    String level = rs.getString("level");
		                    String course = rs.getString("course");
		                    String module = rs.getString("module");

		                    // Populate the fields with the retrieved information
		                    std_name.setText(studentName);
		                    std_level.setText(level);
		                    std_course.setText(course);

		                    // Clear existing items and add the module to the combo box
		                    std_module.removeAllItems();
		                    do {
		                        String module1 = rs.getString("module");
		                        std_module.addItem(module1);
		                    } while (rs.next());

		                    // Initialize grade field
		                    grade.setText("");
		                } else {
		                    // Student ID does not exist
		                    JOptionPane.showMessageDialog(null, "Student ID not found.");

		                    // Clear all fields if student ID is not found
		                    std_name.setText("");
		                    std_level.setText("");
		                    std_course.setText("");
		                    std_module.removeAllItems();
		                    grade.setText(""); 
		                }

		            } catch (SQLException ex) {
		                ex.printStackTrace();
		            }
		        } catch (SQLException ex) {
		            ex.printStackTrace();
		        }
		    }
		});

		
		
		JLabel lblNewLabel_3 = new JLabel("Level:");
		lblNewLabel_3.setFont(new Font("Arial", Font.PLAIN, 14));
		lblNewLabel_3.setBounds(228, 134, 45, 34);
		panel.add(lblNewLabel_3);
		
		
		
		JLabel lblNewLabel_4 = new JLabel("Course:");
		lblNewLabel_4.setFont(new Font("Arial", Font.PLAIN, 14));
		lblNewLabel_4.setBounds(324, 134, 63, 34);
		panel.add(lblNewLabel_4);
		
		std_course = new JTextField();
		std_course.setBounds(378, 136, 190, 34);
		std_course.setEditable(false);
		panel.add(std_course);
		std_course.setColumns(10);
		
		
		
		JLabel lblNewLabel_6 = new JLabel("Insert Marks");
		lblNewLabel_6.setFont(new Font("Arial", Font.PLAIN, 14));
		lblNewLabel_6.setBounds(298, 211, 96, 34);
		panel.add(lblNewLabel_6);
		
		JLabel label_grade = new JLabel("Grade");
		label_grade.setFont(new Font("Arial", Font.PLAIN, 14));
		label_grade.setBounds(465, 211, 57, 35);
		panel.add(label_grade);
		
		JLabel lblNewLabel_2 = new JLabel("Name:");
		lblNewLabel_2.setFont(new Font("Arial", Font.PLAIN, 14));
		lblNewLabel_2.setBounds(10, 136, 63, 34);
		panel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_5 = new JLabel("Modules:");
		lblNewLabel_5.setFont(new Font("Arial", Font.PLAIN, 14));
		lblNewLabel_5.setBounds(10, 211, 77, 34);
		panel.add(lblNewLabel_5);
		

		JButton btnNewButton = new JButton("<-BACK");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				HomeTeacher hteach=new HomeTeacher();
				hteach.setVisible(true);
				dispose();
			}
		});
		btnNewButton.setFont(new Font("Arial", Font.PLAIN, 14));
		btnNewButton.setBounds(10, 433, 85, 29);
		contentPane.add(btnNewButton);
	}
}


