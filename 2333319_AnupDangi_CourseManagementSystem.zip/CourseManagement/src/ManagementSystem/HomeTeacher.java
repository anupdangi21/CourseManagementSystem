//Name:AnupDangi
//wlv id:2333319

package ManagementSystem;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Color;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;

import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class HomeTeacher extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField displayStudents;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					HomeTeacher frame = new HomeTeacher();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public HomeTeacher() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 804, 492);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(35, 103, 133));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(54, 170, 186));
		panel.setBounds(29, 56, 736, 331);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(112, 205, 201));
		panel_1.setBounds(10, 124, 158, 197);
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		JButton viewModule = new JButton("View modules");
		viewModule.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ViewModules vmodules= new ViewModules();
				vmodules.setVisible(true);
				dispose();
			}
		});
		viewModule.setBounds(10, 25, 137, 40);
		panel_1.add(viewModule);
		viewModule.setBackground(new Color(159, 190, 65));
		viewModule.setFont(new Font("Arial", Font.PLAIN, 14));
		
		JButton viewStudent = new JButton("view students");
		viewStudent.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ViewStudents viewStd= new ViewStudents();
				viewStd.setVisible(true);
				dispose();
			}
		});
		viewStudent.setBounds(10, 75, 137, 40);
		panel_1.add(viewStudent);
		viewStudent.setBackground(new Color(159, 190, 65));
		viewStudent.setFont(new Font("Arial", Font.PLAIN, 14));
		
		JButton markStudent = new JButton("Student marking");
		markStudent.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MarkStudents marking=new MarkStudents();
				marking.setVisible(true);
				dispose();
			}
		});
		markStudent.setBounds(10, 125, 137, 40);
		panel_1.add(markStudent);
		markStudent.setBackground(new Color(159, 190, 65));
		markStudent.setFont(new Font("Arial", Font.PLAIN, 14));
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(new Color(112, 205, 201));
		panel_2.setBounds(167, 10, 151, 77);
		panel.add(panel_2);
		panel_2.setLayout(null);
		
		JLabel totalStudents = new JLabel("Total no. of \r\nstudents");
		totalStudents.setFont(new Font("Arial", Font.PLAIN, 14));
		totalStudents.setBounds(10, 10, 138, 28);
		panel_2.add(totalStudents);
		
		displayStudents = new JTextField();
		displayStudents.setBounds(10, 37, 45, 30);
		displayStudents.setEditable(false);
		try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/coursemanagement", "root", "")) {
		    // Execute SQL query to get the count of rows in 'bsc_hons' table
		    String query = "SELECT COUNT(DISTINCT studentid) FROM student;";
		    try (PreparedStatement ps = conn.prepareStatement(query);
		         ResultSet rs = ps.executeQuery()) {

		        // Check if there is a result
		        if (rs.next()) {
		            // Get the count from the result set
		            int totalCount = rs.getInt(1);

		            // Display the total count in the JTextField
		            displayStudents.setText("" + totalCount);
		        } else {
		            // Handle the case where there is no result (optional)
		            displayStudents.setText(": 0");
		        }
		    }
		} catch (SQLException ex) {
		    ex.printStackTrace();
		}
		panel_2.add(displayStudents);
		displayStudents.setColumns(10);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBounds(10, 10, 158, 116);
		panel_3.setBackground(new Color(112, 205, 201));
		panel.add(panel_3);
		panel_3.setLayout(null);
		
		JLabel img_teacher = new JLabel("");
		img_teacher.setBounds(10, 0, 120, 116);
		img_teacher.setIcon(new ImageIcon("C:\\Users\\Acer\\eclipse-workspace\\CourseManagement\\RequiredImages\\home.png"));
		panel_3.add(img_teacher);
		
		JLabel wlc_t = new JLabel("Welcome back...!");//wlc_t represents welcome back variable name from teacher panel
		wlc_t.setFont(new Font("Arial", Font.PLAIN, 15));
		wlc_t.setBounds(29, 22, 137, 29);
		contentPane.add(wlc_t);
		
		JButton logout = new JButton("Logout");
        logout.setBackground(new Color(185, 206, 179));
        logout.setIcon(new ImageIcon("C:\\Users\\Acer\\eclipse-workspace\\CourseManagement\\RequiredImages\\logout.png"));
        logout.setFont(new Font("Arial", Font.PLAIN, 15));
        logout.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Ask for confirmation
                int result = JOptionPane.showConfirmDialog(null, "Are you sure you want to logout?", "Logout Confirmation",
                        JOptionPane.YES_NO_OPTION);

                if (result == JOptionPane.YES_OPTION) {
                    // User confirmed logout
                    // Perform logout operation (e.g., go back to the login page)
                    Main loginFrame = new Main(); // Assuming you have a LoginFrame class for login
                    loginFrame.setVisible(true);
                    dispose(); // Close the current frame (HomeTeacher)
                } else {
                    // User chose not to logout, do nothing or handle accordingly
                }
            }
        });

		logout.setBounds(641, 397, 124, 33);
		contentPane.add(logout);
		
		JLabel t_p = new JLabel("Teacher Panel");
		t_p.setFont(new Font("Arial", Font.PLAIN, 15));//t_p represents the variable name for teacher panel label
		t_p.setBounds(425, 14, 124, 37);
		contentPane.add(t_p);
	}
}
