package ManagementSystem;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;

public class ViewTeacher extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable table_teacher;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ViewTeacher frame = new ViewTeacher();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ViewTeacher() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 590, 411);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(64, 124, 157));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(54, 170, 186));
		panel.setBounds(20, 53, 525, 256);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 10, 505, 236);
		table_teacher = new JTable();
		scrollPane.setViewportView(table_teacher);
			try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/coursemanagement", "root","")) {
					PreparedStatement ps = conn.prepareStatement("SELECT TeacherName,module FROM teacher;");
				ResultSet rs = ps.executeQuery();
				ResultSetMetaData rsmd=rs.getMetaData();
				DefaultTableModel model = (DefaultTableModel) table_teacher.getModel();
				
				int cols = rsmd.getColumnCount();
				String[] colName = new String[cols];
				for (int i = 0; i < cols; i++)
				    colName[i] = rsmd.getColumnName(i + 1);
				model.setColumnIdentifiers(colName);
				String name, Model;
				while(rs.next()) {
					name=rs.getString(1);
					Model=rs.getString(2);
					String[] row= {name,Model};
					model.addRow(row);
					}
				}catch (SQLException ex) {
				ex.printStackTrace();
				}
		panel.add(scrollPane);
		
		
		
		JLabel lblNewLabel = new JLabel("Showing Overall Teacher:");
		lblNewLabel.setFont(new Font("Arial", Font.PLAIN, 14));
		lblNewLabel.setBounds(10, 10, 190, 43);
		contentPane.add(lblNewLabel);
		

		JButton btnNewButton = new JButton("Back");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				HomeStudent student= new HomeStudent();
				student.setVisible(true);
				dispose();
			}
		});
		btnNewButton.setFont(new Font("Arial", Font.PLAIN, 14));
		btnNewButton.setBounds(20, 319, 85, 33);
		contentPane.add(btnNewButton);
	}
}
