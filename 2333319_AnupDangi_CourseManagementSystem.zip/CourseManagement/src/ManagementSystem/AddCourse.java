package ManagementSystem;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class AddCourse extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField course_name;
	private JTextField course_teacher;
	private JTextField new_course;
	private JTextField new_teacher;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AddCourse frame = new AddCourse();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AddCourse() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 627, 483);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(35, 103, 133));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(54, 170, 189));
		panel.setBounds(36, 68, 551, 320);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_2 = new JLabel("CourseName:-");
		lblNewLabel_2.setFont(new Font("Arial", Font.PLAIN, 14));
		lblNewLabel_2.setBounds(10, 21, 108, 38);
		panel.add(lblNewLabel_2);
		
		course_teacher = new JTextField();
		course_teacher.setBounds(169, 67, 172, 33);
		panel.add(course_teacher);
		course_teacher.setColumns(10);
		
		new_teacher = new JTextField();
		new_teacher.setBounds(169, 224, 172, 31);
		panel.add(new_teacher);
		new_teacher.setColumns(10);
		
		course_name = new JTextField();
		course_name.setBounds(169, 26, 172, 31);
		panel.add(course_name);
		course_name.setColumns(10);
		
		JButton btnNewButton_1 = new JButton("Add");
		btnNewButton_1.setBounds(456, 272, 85, 38);
		panel.add(btnNewButton_1);

		btnNewButton_1.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        String coursename = course_name.getText();
		        String teacher = course_teacher.getText();

		        // Check if fields are filled
		        if (coursename.trim().isEmpty() || teacher.trim().isEmpty()) {
		            JOptionPane.showMessageDialog(null, "Fill in all fields properly.");
		            return; // Stop further execution if fields are not filled
		        }

		        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/coursemanagement", "root", "")) {
		            PreparedStatement ps = conn.prepareStatement("INSERT INTO course (CourseName, CourseTeacher) VALUES (?, ?)");
		            ps.setString(1, coursename);
		            ps.setString(2, teacher);

		            int z = ps.executeUpdate();

		            if (z > 0)
		                JOptionPane.showMessageDialog(null, "Course added successfully!");
		            else
		                JOptionPane.showMessageDialog(null, "Error adding course");

		        } catch (SQLException ex) {
		            ex.printStackTrace();
		        }
		    }
		});

		btnNewButton_1.setFont(new Font("Arial", Font.PLAIN, 14));
		
		JLabel lblNewLabel_3 = new JLabel("Course Teacher:");
		lblNewLabel_3.setFont(new Font("Arial", Font.PLAIN, 14));
		lblNewLabel_3.setBounds(10, 69, 108, 31);
		panel.add(lblNewLabel_3);
		
		JButton btn_delete = new JButton("Delete");
		btn_delete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
		        String CourseToDelete = course_name.getText();
		        

		        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/coursemanagement", "root", "")) {
		            // Check if the teacher data exists
		            PreparedStatement checkIfExists = conn.prepareStatement("SELECT * FROM course WHERE CourseName = ?");
		            checkIfExists.setString(1, CourseToDelete);
		            ResultSet resultSet = checkIfExists.executeQuery();

		            if (resultSet.next()) {
		                // Teacher data exists, proceed with deletion
		                PreparedStatement ps = conn.prepareStatement("DELETE FROM course WHERE CourseName = ?");
		                ps.setString(1, CourseToDelete);

		                int rowsAffected = ps.executeUpdate();
		                if (rowsAffected > 0) {
		                    JOptionPane.showMessageDialog(null, "course Deleted successfully!");
		                } else {
		                    JOptionPane.showMessageDialog(null, "Error occurred while deleting course.");
		                }
		            } else {
		                // Teacher data doesn't exist
		                JOptionPane.showMessageDialog(null, "course not found");
		            }
		        } catch (SQLException ex) {
		            ex.printStackTrace();
		        }
		    }
		});
		btn_delete.setFont(new Font("Arial", Font.PLAIN, 14));
		btn_delete.setBounds(456, 224, 85, 38);
		panel.add(btn_delete);
		
		JButton btnNewButton_2 = new JButton("Update");
		btnNewButton_2.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        String CourseToUpdate = course_name.getText();
		        String newCourseName = new_course.getText();
		        String courseTeacher = new_teacher.getText();

		        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/coursemanagement", "root", "")) {
		            // Check if the course data exists based on the old course name
		            PreparedStatement checkIfExists = conn.prepareStatement("SELECT * FROM course WHERE CourseName = ?");
		            checkIfExists.setString(1, CourseToUpdate);
		            ResultSet resultSet = checkIfExists.executeQuery();

		            if (resultSet.next()) {
		                // Course exists based on the old course name, now check if the new course name already exists
		                PreparedStatement checkNewCourseName = conn.prepareStatement("SELECT * FROM course WHERE CourseName = ?");
		                checkNewCourseName.setString(1, newCourseName);
		                ResultSet newCourseResultSet = checkNewCourseName.executeQuery();

		                if (newCourseResultSet.next()) {
		                    // New course name already exists
		                    JOptionPane.showMessageDialog(null, "course name already exists. Choose a different name.");
		                } else {
		                    // Update the course with the new course name and teacher
		                    PreparedStatement updateCourse = conn.prepareStatement("UPDATE course SET CourseName = ?, CourseTeacher = ? WHERE CourseName = ?");
		                    updateCourse.setString(1, newCourseName);
		                    updateCourse.setString(2, courseTeacher);
		                    updateCourse.setString(3, CourseToUpdate);

		                    int rowsAffected = updateCourse.executeUpdate();
		                    if (rowsAffected > 0) {
		                        JOptionPane.showMessageDialog(null, "Course updated successfully!");
		                    } else {
		                        JOptionPane.showMessageDialog(null, "Error occurred while updating course.");
		                    }
		                }
		            } else {
		                // Course data doesn't exist based on the old course name
		                JOptionPane.showMessageDialog(null, "Course not found");
		            }
		        } catch (SQLException ex) {
		            ex.printStackTrace();
		        }
		    }
		});

		btnNewButton_2.setFont(new Font("Arial", Font.PLAIN, 14));
		btnNewButton_2.setBounds(361, 273, 85, 38);
		panel.add(btnNewButton_2);
		
		JLabel lblNewLabel_4 = new JLabel("For Updating purpose only:");
		lblNewLabel_4.setFont(new Font("Arial", Font.BOLD, 14));
		lblNewLabel_4.setBounds(7, 143, 298, 22);
		panel.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("Enter New Course Name");
		lblNewLabel_5.setFont(new Font("Arial", Font.PLAIN, 14));
		lblNewLabel_5.setBounds(10, 175, 174, 31);
		panel.add(lblNewLabel_5);
		
		new_course = new JTextField();
		new_course.setBounds(169, 176, 172, 31);
		panel.add(new_course);
		new_course.setColumns(10);
		
		JLabel lblNewLabel_6 = new JLabel("New Course Teacher:");
		lblNewLabel_6.setFont(new Font("Arial", Font.PLAIN, 14));
		lblNewLabel_6.setBounds(10, 216, 149, 38);
		panel.add(lblNewLabel_6);
	
		JLabel lblNewLabel = new JLabel("Adding New course");
		lblNewLabel.setFont(new Font("Arial", Font.BOLD, 14));
		lblNewLabel.setBounds(36, 26, 171, 48);
		contentPane.add(lblNewLabel);
		
		JButton btnNewButton = new JButton("Skip");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Administration skip = new Administration();
				skip.setVisible(true);;
				dispose();
			}
		});
		btnNewButton.setFont(new Font("Arial", Font.PLAIN, 14));
		btnNewButton.setBounds(36, 398, 85, 38);
		contentPane.add(btnNewButton);
	}
}
