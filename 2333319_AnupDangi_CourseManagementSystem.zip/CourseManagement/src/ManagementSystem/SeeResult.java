package ManagementSystem;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.Color;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class SeeResult extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField display_ID;
	private JTable table_result;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SeeResult frame = new SeeResult();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SeeResult() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 597, 401);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(35, 103, 133));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Viewing Results");
		lblNewLabel.setBounds(10, 10, 138, 23);
		lblNewLabel.setFont(new Font("Arial", Font.PLAIN, 14));
		contentPane.add(lblNewLabel);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(54, 170, 189));
		panel.setBounds(10, 43, 563, 260);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("Enter Your Student ID:");
		lblNewLabel_1.setFont(new Font("Arial", Font.PLAIN, 14));
		lblNewLabel_1.setBounds(73, 21, 163, 37);
		panel.add(lblNewLabel_1);
		
		display_ID = new JTextField();
		display_ID.setBounds(229, 22, 135, 37);
		panel.add(display_ID);
		display_ID.setColumns(10);
		
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 97, 528, 153);
		panel.add(scrollPane);
		
		table_result = new JTable();
		scrollPane.setViewportView(table_result);
		
		JButton btnNewButton_2 = new JButton("VIEW");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			    try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/coursemanagement", "root", "")) {
			        String studentid = display_ID.getText();

			        // Prepare the SQL statement with a parameterized query
			        PreparedStatement ps = conn.prepareStatement("SELECT studentName, level, modules, marks, grade FROM marks WHERE studentid = ?");
			        
			        // Set the value for the parameter
			        ps.setString(1, studentid);

			        ResultSet rs = ps.executeQuery();
			        ResultSetMetaData rsmd = rs.getMetaData();
			        DefaultTableModel model = (DefaultTableModel) table_result.getModel();

			        // Clear existing rows
			        model.setRowCount(0);

			        int cols = rsmd.getColumnCount();
			        String[] colName = new String[cols];

			        for (int i = 0; i < cols; i++) {
			            colName[i] = rsmd.getColumnName(i + 1);
			        }

			        model.setColumnIdentifiers(colName);

			        String name, level, modules, marks, grade;

			        while (rs.next()) {
			            name = rs.getString(1);
			            level = rs.getString(2);
			            modules = rs.getString(3);
			            marks=rs.getString(4);
			            grade=rs.getString(5);
			            String[] row = {name, level, modules, marks, grade};
			            model.addRow(row);
			        }
			    } catch (SQLException ex) {
			        ex.printStackTrace();
			    }
			}
		});


		btnNewButton_2.setBounds(374, 30, 62, 21);
		panel.add(btnNewButton_2);

		
		JLabel lblNewLabel_2 = new JLabel("Your Grades are displaying below:-");
		lblNewLabel_2.setFont(new Font("Arial", Font.PLAIN, 12));
		lblNewLabel_2.setBounds(10, 74, 208, 13);
		panel.add(lblNewLabel_2);
		
		JButton btnNewButton_1 = new JButton("Skip");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				HomeStudent homestd= new HomeStudent();
				homestd.setVisible(true);
				dispose();
			}
		});
		btnNewButton_1.setFont(new Font("Arial", Font.PLAIN, 14));
		btnNewButton_1.setBounds(10, 313, 85, 41);
		contentPane.add(btnNewButton_1);
	}

}
