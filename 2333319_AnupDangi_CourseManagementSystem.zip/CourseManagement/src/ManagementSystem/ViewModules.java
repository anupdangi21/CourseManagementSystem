package ManagementSystem;

import java.awt.EventQueue;


import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JTable;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import javax.swing.JTextField;

public class ViewModules extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable table_foryou;
	private JTable table_forall;
	private JTextField id_teacher;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ViewModules frame = new ViewModules();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ViewModules() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 952, 510);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(35, 103, 133));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(54, 170, 189));
		panel.setBounds(10, 72, 437, 325);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel btn_foryou = new JLabel("Showing modules for you:");
		btn_foryou.setFont(new Font("Arial", Font.BOLD, 14));
		btn_foryou.setBounds(10, 10, 196, 33);
		panel.add(btn_foryou);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 98, 401, 204);
		panel.add(scrollPane);
		
		id_teacher = new JTextField();
		id_teacher.setBounds(110, 53, 182, 35);
		panel.add(id_teacher);
		id_teacher.setColumns(10);
		
		table_foryou = new JTable();
		table_foryou.setFont(new Font("Arial", Font.PLAIN, 14));
		scrollPane.setViewportView(table_foryou);
		table_foryou.setBackground(new Color(180, 225, 235));
		
		JButton btnNewButton_2 = new JButton("View");
		btnNewButton_2.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/coursemanagement", "root", "")) {
		            String teacherId = id_teacher.getText();

		            // Check if the teacher is registered
		            String teacherQuery = "SELECT TeacherName, module FROM teacher WHERE TeacherID = ?";
		            try (PreparedStatement teacherPS = conn.prepareStatement(teacherQuery)) {
		                teacherPS.setString(1, teacherId);

		                ResultSet teacherRS = teacherPS.executeQuery();

		                DefaultTableModel model = (DefaultTableModel) table_foryou.getModel();

		                // Clear existing table data
		                model.setRowCount(0);

		                // Display modules if the teacher is registered
		                if (teacherRS.next()) {
		                    String teacherName = teacherRS.getString("TeacherName");

		                    // Retrieve modules assigned to the teacher
		                    String moduleQuery = "SELECT TeacherName,module FROM teacher WHERE TeacherID = ?";
		                    try (PreparedStatement modulePS = conn.prepareStatement(moduleQuery)) {
		                        modulePS.setString(1, teacherId);

		                        ResultSet moduleRS = modulePS.executeQuery();

		                        // Get the metadata for the result set
		                        ResultSetMetaData rsmd = moduleRS.getMetaData();
		                        int cols = rsmd.getColumnCount();
		                        String[] colName = new String[cols];
		                        for (int i = 0; i < cols; i++)
		                            colName[i] = rsmd.getColumnName(i + 1);
		                        model.setColumnIdentifiers(colName);

		                        // Display modules in the table
		                        while (moduleRS.next()) {
		                            String moduleName = moduleRS.getString("module");
		                            String[] row = {teacherName, moduleName};
		                            model.addRow(row);
		                        }
		                    }
		                } else {
		                    // Teacher not found
		                    JOptionPane.showMessageDialog(null, "Teacher ID not found.");
		                }
		            }
		        } catch (SQLException ex) {
		            ex.printStackTrace();
		        }
		    }
		});




		btnNewButton_2.setFont(new Font("Arial", Font.PLAIN, 14));
		btnNewButton_2.setBounds(326, 50, 85, 38);
		panel.add(btnNewButton_2);
		
		JLabel lblNewLabel_1 = new JLabel("Enter your ID:");
		lblNewLabel_1.setFont(new Font("Arial", Font.PLAIN, 14));
		lblNewLabel_1.setBounds(10, 53, 112, 33);
		panel.add(lblNewLabel_1);
		
		
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(54, 170, 189));
		panel_1.setBounds(446, 72, 448, 325);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel_2 = new JLabel("Showing all modules");
		lblNewLabel_2.setFont(new Font("Arial", Font.BOLD, 14));
		lblNewLabel_2.setBounds(10, 10, 156, 29);
		panel_1.add(lblNewLabel_2);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(20, 56, 395, 245);
		panel_1.add(scrollPane_1);
		
		table_forall = new JTable();
		table_forall.setFont(new Font("Arial", Font.PLAIN, 14));
		scrollPane_1.setViewportView(table_forall);
		table_forall.setBackground(new Color(180, 225, 235));
		
		JButton btn_forall = new JButton("View All");
		btn_forall.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
					try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/coursemanagement", "root","")) {
	 					PreparedStatement ps = conn.prepareStatement("SELECT TeacherName,module FROM teacher;");
						ResultSet rs = ps.executeQuery();
						ResultSetMetaData rsmd=rs.getMetaData();
						DefaultTableModel model = (DefaultTableModel) table_forall.getModel();
						
						int cols = rsmd.getColumnCount();
						String[] colName = new String[cols];
						for (int i = 0; i < cols; i++)
						    colName[i] = rsmd.getColumnName(i + 1);
						model.setColumnIdentifiers(colName);
						String name, Model;
						while(rs.next()) {
							name=rs.getString(1);
							Model=rs.getString(2);
							String[] row= {name,Model};
							model.addRow(row);
							}
						}catch (SQLException ex) {
						ex.printStackTrace();
					}
				}
			});
		btn_forall.setFont(new Font("Arial", Font.PLAIN, 14));
		btn_forall.setBounds(176, 6, 85, 36);
		panel_1.add(btn_forall);
		
		JLabel lblNewLabel = new JLabel("Viewing Modules:");
		lblNewLabel.setFont(new Font("Arial", Font.BOLD, 14));
		lblNewLabel.setBounds(10, 10, 170, 40);
		contentPane.add(lblNewLabel);
		
		JButton btnNewButton = new JButton("Logout");
		btnNewButton.setIcon(new ImageIcon("C:\\Users\\Acer\\eclipse-workspace\\CourseManagement\\RequiredImages\\logout.png"));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int result = JOptionPane.showConfirmDialog(null, "Are you sure you want to logout?", "Logout Confirmation",
                        JOptionPane.YES_NO_OPTION);

                if (result == JOptionPane.YES_OPTION) {
                    Main main = new Main(); 
                    main.setVisible(true);
                    dispose(); 
                } else {
                    
                }
            }
        });
		btnNewButton.setFont(new Font("Arial", Font.PLAIN, 14));
		btnNewButton.setBounds(740, 407, 154, 40);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Back");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				HomeTeacher homet= new HomeTeacher();
				homet.setVisible(true);
				dispose();
			}
		});
		btnNewButton_1.setFont(new Font("Arial", Font.PLAIN, 14));
		btnNewButton_1.setBounds(10, 407, 90, 40);
		contentPane.add(btnNewButton_1);
	}
}
