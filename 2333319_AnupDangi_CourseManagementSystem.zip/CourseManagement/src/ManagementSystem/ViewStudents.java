package ManagementSystem;

import java.awt.Color;


import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;


import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JPasswordField;

public class ViewStudents extends JFrame {
    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField std_id;
    private JTextField std_name;
    private JTextField std_year;
    private JTable table_student;
    private JPasswordField std_password;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    ViewStudents frame = new ViewStudents();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public ViewStudents() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 786, 520);
        contentPane = new JPanel();
        contentPane.setBackground(new Color(35, 103, 133));
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblNewLabel = new JLabel("Viewing Students");
        lblNewLabel.setFont(new Font("Arial", Font.BOLD, 16));
        lblNewLabel.setBounds(20, 9, 181, 37);
        contentPane.add(lblNewLabel);

        JButton btnNewButton = new JButton("<-BACK");
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                HomeTeacher hometeacher = new HomeTeacher();
                hometeacher.setVisible(true);
                dispose();
            }
        });
        btnNewButton.setFont(new Font("Arial", Font.PLAIN, 14));
        btnNewButton.setBounds(20, 427, 90, 35);
        contentPane.add(btnNewButton);

       

        JButton btnNewButton_2 = new JButton("Delete Student");
        btnNewButton_2.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
		        String teacherIdToDelete = std_id.getText();

		        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/coursemanagement", "root", "")) {
		            // Check if the teacher data exists
		            PreparedStatement checkIfExists = conn.prepareStatement("SELECT * FROM student WHERE studentId = ?");
		            checkIfExists.setString(1, teacherIdToDelete);
		            ResultSet resultSet = checkIfExists.executeQuery();

		            if (resultSet.next()) {
		                // Teacher data exists, proceed with deletion
		                PreparedStatement ps = conn.prepareStatement("DELETE FROM student WHERE studentId = ?");
		                ps.setString(1, teacherIdToDelete);

		                int rowsAffected = ps.executeUpdate();
		                if (rowsAffected > 0) {
		                    JOptionPane.showMessageDialog(null, "Student Deleted successfully!");
		                } else {
		                    JOptionPane.showMessageDialog(null, "Error occurred while deleting student.");
		                }
		            } else {
		                // Teacher data doesn't exist
		                JOptionPane.showMessageDialog(null, "student not found");
		            }
		        } catch (SQLException ex) {
		            ex.printStackTrace();
		        }
		    }
		});
        btnNewButton_2.setFont(new Font("Arial", Font.PLAIN, 14));
        btnNewButton_2.setBounds(602, 427, 136, 35);
        contentPane.add(btnNewButton_2);

        JPanel panel = new JPanel();
        panel.setBackground(new Color(54, 170, 186));
        panel.setBounds(20, 39, 718, 363);
        contentPane.add(panel);
        panel.setLayout(null);
        
        JLabel lblNewLabel_1 = new JLabel("Insert Records");
        lblNewLabel_1.setFont(new Font("Arial", Font.BOLD, 14));
        lblNewLabel_1.setBounds(10, 6, 123, 28);
        panel.add(lblNewLabel_1);
        
        JPanel panel_1 = new JPanel();
        panel_1.setBackground(new Color(54, 170, 189));
        panel_1.setBounds(0, 40, 226, 323);
        panel.add(panel_1);
        panel_1.setLayout(null);
        
        JLabel lblNewLabel_2 = new JLabel("StudentID");
        lblNewLabel_2.setFont(new Font("Arial", Font.PLAIN, 14));
        lblNewLabel_2.setBounds(10, 0, 70, 29);
        panel_1.add(lblNewLabel_2);
        
        std_id = new JTextField();
        std_id.setBounds(77, 0, 114, 25);
        panel_1.add(std_id);
        std_id.setColumns(10);
        
        JLabel lblNewLabel_3 = new JLabel("Name:");
        lblNewLabel_3.setFont(new Font("Arial", Font.PLAIN, 14));
        lblNewLabel_3.setBounds(10, 39, 57, 29);
        panel_1.add(lblNewLabel_3);
        
        std_name = new JTextField();
        std_name.setBounds(77, 39, 114, 25);
        panel_1.add(std_name);
        std_name.setColumns(10);
        
        JLabel lblNewLabel_4 = new JLabel("Course");
        lblNewLabel_4.setFont(new Font("Arial", Font.PLAIN, 14));
        lblNewLabel_4.setBounds(10, 78, 57, 25);
        panel_1.add(lblNewLabel_4);
        
        JLabel lblNewLabel_5 = new JLabel("level");
        lblNewLabel_5.setFont(new Font("Arial", Font.PLAIN, 14));
        lblNewLabel_5.setBounds(10, 113, 45, 25);
        panel_1.add(lblNewLabel_5);
        JComboBox combo_module = new JComboBox();
        combo_module.setBounds(77, 178, 114, 21);
        panel_1.add(combo_module);
        
        JComboBox std_level = new JComboBox();
        std_level.setFont(new Font("Arial", Font.PLAIN, 14));
        std_level.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
	        // Clear existing items in Module_Info
	        combo_module.removeAllItems();

	        // Get the selected level
	        String selectedLevel = std_level.getSelectedItem().toString();

	        if ("4".equals(selectedLevel)) {
	            // Level 4 modules
	            String[] level4Modules = {
	                    "Academic Skills and Team Based Learning",
	                    "Introductory Programming and Problem Solving",
	                    "Fundamentals of Computing",
	                    "Embedded System Programming",
	                    "Internet Software Architecture",
	                    "Computational Mathematics",
	            };
	            for (String module : level4Modules) {
	                combo_module.addItem(module);
	            }
	        }if ("5".equals(selectedLevel)) {
	            // Level 5 modules
	            String[] level5Modules = {
	            		"Al",
		                "oop", 
		                "nmc",
		                "cloud computing", 
		                "Collaborative Development", 
		                "Human Computer Interaction",
	            };
	            for (String module : level5Modules) {
	                combo_module.addItem(module);
	            }
	        }if ("6".equals(selectedLevel)) {
	        	String[] level6Modules = {
	        			"Complex Systems",
	        			"High Performance Computing",
	        			"Project and Professionalism",
	        			"Artificial Intelligence and Machine Learning",
	        			"Big Data",
	        };
	        	for(String module : level6Modules) {
	        		combo_module.addItem(module);
	        	}
	    }
        }
	});
    	std_level.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3", "4", "5", "6"}));
        std_level.setBounds(77, 109, 45, 21);
        panel_1.add(std_level);
        
        JLabel lblNewLabel_6 = new JLabel("Year");
        lblNewLabel_6.setFont(new Font("Arial", Font.PLAIN, 14));
        lblNewLabel_6.setBounds(10, 139, 70, 29);
        panel_1.add(lblNewLabel_6);
        
        std_year = new JTextField();
        std_year.setBounds(77, 140, 114, 25);
        panel_1.add(std_year);
        std_year.setColumns(10);
        
        JLabel lblNewLabel_7 = new JLabel("Modules:");
        lblNewLabel_7.setFont(new Font("Arial", Font.PLAIN, 14));
        lblNewLabel_7.setBounds(10, 177, 57, 25);
        panel_1.add(lblNewLabel_7);
        
        
        
        JComboBox std_course = new JComboBox();
        std_course.setModel(new DefaultComboBoxModel(new String[] {"", "Bsc(Hons) in Computer Science", "BIBM"}));
        std_course.setBounds(77, 74, 114, 21);
        panel_1.add(std_course);
        
        JLabel lblNewLabel_9 = new JLabel("Password:");
        lblNewLabel_9.setFont(new Font("Arial", Font.PLAIN, 14));
        lblNewLabel_9.setBounds(10, 212, 70, 21);
        panel_1.add(lblNewLabel_9);
        
        std_password = new JPasswordField();
        std_password.setBounds(90, 204, 101, 29);
        panel_1.add(std_password);
        
        JPanel panel_2 = new JPanel();
        panel_2.setBackground(new Color(54, 170, 189));
        panel_2.setBounds(0, 0, 718, 39);
        panel.add(panel_2);
        panel_2.setLayout(null);
        
        JLabel lblNewLabel_8 = new JLabel("Overall Students");
        lblNewLabel_8.setFont(new Font("Arial", Font.BOLD, 14));
        lblNewLabel_8.setBounds(229, 10, 263, 29);
        panel_2.add(lblNewLabel_8);
        
        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(225, 40, 493, 323);
        panel.add(scrollPane);
        
        table_student = new JTable();
        scrollPane.setViewportView(table_student);
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/coursemanagement", "root", "")) {
            PreparedStatement ps = conn.prepareStatement("SELECT studentId, studentName, course, module, level FROM student;");
            ResultSet rs = ps.executeQuery();
            ResultSetMetaData rsmd = rs.getMetaData();
			DefaultTableModel model = (DefaultTableModel) table_student.getModel();

            int cols = rsmd.getColumnCount();
            String[] colName = new String[cols];

            for (int i = 0; i < cols; i++) {
                colName[i] = rsmd.getColumnName(i + 1);
            }

            model.setColumnIdentifiers(colName);

            String id, name, course, Model, level;
            
            while (rs.next()) {
                id = rs.getString(1);
                name = rs.getString(2);
                course = rs.getString(3);
                Model = rs.getString(4);
                level = rs.getString(5);
                
                String[] row = {id, name, course, Model, level};
                model.addRow(row);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        
        JButton btnNewButton_1 = new JButton("Add Students");
        btnNewButton_1.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
		        String studentId = std_id.getText();
		        String studentName = std_name.getText();
		        String course = std_course.getSelectedItem().toString();
		        String modules = combo_module.getSelectedItem().toString();
		        String password = new String(std_password.getPassword());
		        String level = std_level.getSelectedItem().toString();
		        String semester= std_year.getText();

		        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/coursemanagement", "root", "")) {
		            // Check if the student with the given studentId already exists
		            PreparedStatement checkIfExists = conn.prepareStatement("SELECT * FROM student WHERE studentId = ?");
		            checkIfExists.setString(1, studentId);
		            ResultSet resultSet = checkIfExists.executeQuery();

		            if (resultSet.next()) {
		                // Student with the given studentId already exists
		                JOptionPane.showMessageDialog(null, "Student with this ID already exists. Choose a different ID.");
		            } else {
		            	for (int i = 0; i < combo_module.getItemCount(); i++) {
			                String module = combo_module.getItemAt(i).toString();
		                // Insert the new student data
		                PreparedStatement ps = conn.prepareStatement("INSERT INTO student (studentId, studentName, course, module, password, level, year) VALUES (?, ?, ?, ?, ?, ?, ?)");
		                ps.setString(1, studentId);
		                ps.setString(2, studentName);
		                ps.setString(3, course);
		                ps.setString(4, module);
		                ps.setString(5, password);
		                ps.setString(6, level);
		                ps.setString(7, semester);

		                int z = ps.executeUpdate();
		                if (z > 0)
		                    JOptionPane.showMessageDialog(null, "Student added successfully...!");
		                else
		                    JOptionPane.showMessageDialog(null, "Error");
		            	}
		            }
		        } catch (SQLException ex) {
		            ex.printStackTrace();
		        }
		    }
		});
        btnNewButton_1.setFont(new Font("Arial", Font.PLAIN, 14));
        btnNewButton_1.setBounds(254, 427, 123, 35);
        contentPane.add(btnNewButton_1);
    }
}
        
        
        
      
