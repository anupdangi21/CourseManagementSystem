package ManagementSystem;

import java.awt.EventQueue;


import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import java.awt.Color;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;

public class Enrollment extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private final JLabel std_e = new JLabel("STUDENT ID:");
	private JTextField textField_id;
	private JTextField textField_fn;
	private JTextField textField_S;
	private JTextField lvl6_first;
	private JTextField lvl6_second;
	private JPasswordField passwordField_e;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Enrollment frame = new Enrollment();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}


	/**
	 * Create the frame.
	 */
	public Enrollment() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 647, 507);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(35, 103, 133));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("logged in as Student");
		lblNewLabel.setFont(new Font("Arial", Font.PLAIN, 14));
		lblNewLabel.setBounds(10, 10, 139, 32);
		contentPane.add(lblNewLabel);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(54, 170, 189));
		panel.setBounds(20, 52, 591, 365);
		contentPane.add(panel);
		panel.setLayout(null);
		std_e.setBounds(10, 46, 91, 36);
		std_e.setFont(new Font("Arial", Font.PLAIN, 14));
		panel.add(std_e);
		
		textField_id = new JTextField();
		textField_id.setBounds(111, 51, 110, 29);
		panel.add(textField_id);
		textField_id.setColumns(10);
		
		JLabel fn_e = new JLabel("FULL NAME:");
		fn_e.setBounds(10, 81, 91, 36);
		fn_e.setFont(new Font("Arial", Font.PLAIN, 14));
		panel.add(fn_e);
		
		textField_fn = new JTextField();
		textField_fn.setBounds(111, 90, 110, 29);
		panel.add(textField_fn);
		textField_fn.setColumns(10);
		
		JLabel sc_e = new JLabel("SELECT COURSE:");
		sc_e.setBounds(10, 127, 137, 36);
		sc_e.setFont(new Font("Arial", Font.PLAIN, 14));
		panel.add(sc_e);
		
		JComboBox comboBox_sc = new JComboBox();
		comboBox_sc.setBounds(145, 129, 118, 32);
		comboBox_sc.setModel(new DefaultComboBoxModel(new String[] {"", "BSc(Hons) in ComputerScience", "BIBM"}));
		comboBox_sc.setFont(new Font("Arial", Font.PLAIN, 14));
		panel.add(comboBox_sc);
		
		JLabel enroll = new JLabel("ENROLL COURSE");
		enroll.setBounds(10, 10, 211, 26);
		enroll.setBackground(new Color(173, 179, 211));
		enroll.setFont(new Font("Arial", Font.BOLD, 15));
		panel.add(enroll);
		
		JLabel l_e = new JLabel("LEVEL:");
		l_e.setBounds(280, 131, 48, 29);
		l_e.setFont(new Font("Arial", Font.PLAIN, 14));
		panel.add(l_e);
		
		JComboBox Module_Info = new JComboBox();
		Module_Info.setBounds(96, 214, 220, 26);
		panel.add(Module_Info);
		
		passwordField_e = new JPasswordField();
		passwordField_e.setBounds(322, 51, 130, 29);
		panel.add(passwordField_e);
		
		JLabel moduleCount = new JLabel("Modules:");
		moduleCount.setBounds(10, 209, 65, 29);
		moduleCount.setFont(new Font("Arial", Font.PLAIN, 14));
		panel.add(moduleCount);
		
		lvl6_second = new JTextField();
		lvl6_second.setBounds(342, 278, 110, 31);
		panel.add(lvl6_second);
		lvl6_second.setColumns(10);

		JComboBox comboBox_l = new JComboBox();
		comboBox_l.setBounds(342, 133, 55, 30);
		comboBox_l.setFont(new Font("Arial", Font.PLAIN, 14));
		comboBox_l.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3", "4", "5", "6"}));
		panel.add(comboBox_l);
	
		comboBox_l.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			    // Clear existing items in Module_Info
			    Module_Info.removeAllItems();

			    // Get the selected level
			    String selectedLevel = comboBox_l.getSelectedItem().toString();

			    if ("4".equals(selectedLevel)) {
			        // Level 4 modules
			        String[] level4Modules = {
			                "Academic Skills and Team Based Learning",
			                "Introductory Programming and Problem Solving",
			                "Fundamentals of Computing", 
			                "Embedded System Programming", 
			                "Internet Software Architecture", 
			                "Computational Mathematics",
			        };
			        for (String module : level4Modules) {
			            Module_Info.addItem(module);
			        }
			    } else if ("5".equals(selectedLevel)) {
			        // Level 5 modules
			        String[] level5Modules = {
			                "Al",
			                "oop", 
			                "nmc",
			                "cloud computing", 
			                "Collaborative Development", 
			                "Human Computer Interaction",
			        };
			        for (String module : level5Modules) {
			            Module_Info.addItem(module);
			        }
			    } else if ("6".equals(selectedLevel)) {
			        // Level 6 modules
			        String[] level6Modules = {
			                "Complex Systems", 
			                "High Performance Computing",
			                "Artificial Intelligence and Machine Learning",
			                "Big Data", 
			        };
			        String first = lvl6_first.getText();
			        String second = lvl6_second.getText();

			        for (String module : level6Modules) {
			            Module_Info.addItem(module);
			        }

			        // choice for  the additional modules for level 6
			        Module_Info.addItem(first);
			        Module_Info.addItem(second);
			    }
			}
		});

		comboBox_l.setModel(new DefaultComboBoxModel(new String[] {"4", "5", "6"}));
		panel.add(comboBox_l);
		
		JLabel s_e = new JLabel("Year");
		s_e.setBounds(10, 173, 91, 26);
		s_e.setFont(new Font("Arial", Font.PLAIN, 14));
		panel.add(s_e);
		
		textField_S = new JTextField();
		textField_S.setBounds(111, 173, 109, 26);
		panel.add(textField_S);
		textField_S.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Enter Your Choice Modules:(For level 6 only)");
		lblNewLabel_1.setFont(new Font("Arial", Font.BOLD, 14));
		lblNewLabel_1.setBounds(10, 248, 330, 26);
		panel.add(lblNewLabel_1);
		
		lvl6_first = new JTextField();
		lvl6_first.setBounds(111, 278, 96, 29);
		panel.add(lvl6_first);
		lvl6_first.setColumns(10);
		
		JButton btnNewButton_1 = new JButton("ENROLL");
		btnNewButton_1.setBounds(482, 322, 99, 33);
		panel.add(btnNewButton_1);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			    String studentid = textField_id.getText();
			    String fullname = textField_fn.getText();
			    String course = comboBox_sc.getSelectedItem().toString();
			    String level = comboBox_l.getSelectedItem().toString();
			    String year = textField_S.getText();
			    String password = new String(passwordField_e.getPassword());

			    // Set the default table name
			    String tableName1 = "it";
			    String tableName = "student";

			    String loggedInUsername = "textField_id.getText()"; 

			    // Check the selected course and update the table name accordingly
			    if ("BSc(Hons)".equals(course)) {
			        tableName = "student";
			    } else if ("BIBM".equals(course)) {
			        tableName = "enroll_bibm";
			    }

			    try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/coursemanagement", "root", "")) {
			        // Check if the student already exists
			        PreparedStatement checkIfExists = conn.prepareStatement("SELECT * FROM " + tableName + " WHERE StudentID = ?");
			        checkIfExists.setString(1, studentid);
			        ResultSet resultSet = checkIfExists.executeQuery();

			        if (resultSet.next()) {
			            JOptionPane.showMessageDialog(null, "You are already enrolled.");
			        } else {
			            // Enroll each module separately
			            for (int i = 0; i < Module_Info.getItemCount(); i++) {
			                String module = Module_Info.getItemAt(i).toString();
			                try {
			                    PreparedStatement ps = conn.prepareStatement("INSERT INTO " + tableName + " (StudentId, studentName,Course,module,password,level, year ) VALUES (?,?,?,?,?,?,?)");
			                    ps.setString(1, studentid);
			                    ps.setString(2, fullname);
			                    ps.setString(3, course);
			                    ps.setString(4, module);
			                    ps.setString(5, password);
			                    ps.setString(6, level);
			                    ps.setString(7, year);
			                    
			                    

			                    int z = ps.executeUpdate();
			                    if (z > 0)
			                        JOptionPane.showMessageDialog(null, "Enrolled Successfully for Module: " + module);
			                    else
			                        JOptionPane.showMessageDialog(null, "Error while enrolling for Module: " + module);
			                } catch (SQLException ex) {
			                    ex.printStackTrace();
			                    JOptionPane.showMessageDialog(null, "Error while preparing statement or executing query for Module: " + module);
			                }
			            }
			        }
			    } catch (SQLException ex) {
			        ex.printStackTrace();
			        JOptionPane.showMessageDialog(null, "Error while connecting to the database.");
			    }
			}
		});
				btnNewButton_1.setFont(new Font("Arial", Font.PLAIN, 14));
				
				JLabel lblNewLabel_2 = new JLabel("Modules first:");
				lblNewLabel_2.setFont(new Font("Arial", Font.PLAIN, 14));
				lblNewLabel_2.setBounds(10, 280, 91, 22);
				panel.add(lblNewLabel_2);
				
				JLabel lblNewLabel_3 = new JLabel("Module Second:");
				lblNewLabel_3.setFont(new Font("Arial", Font.PLAIN, 14));
				lblNewLabel_3.setBounds(218, 278, 110, 29);
				panel.add(lblNewLabel_3);
				
				JLabel lblNewLabel_4 = new JLabel("Password");
				lblNewLabel_4.setFont(new Font("Arial", Font.PLAIN, 14));
				lblNewLabel_4.setBounds(238, 51, 75, 29);
				panel.add(lblNewLabel_4);

		
		JButton back_e = new JButton("<-BACK");
		back_e.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
                // Ask for confirmation
                int result = JOptionPane.showConfirmDialog(null, "Are you sure?", "Logout Confirmation",
                        JOptionPane.YES_NO_OPTION);

                if (result == JOptionPane.YES_OPTION) {
                    HomeStudent homestd = new HomeStudent(); 
                    homestd.setVisible(true);
                    dispose(); 
                } else {
                    
                }
            }
        });
		back_e.setFont(new Font("Arial", Font.PLAIN, 14));
		back_e.setBounds(20, 427, 85, 33);
		contentPane.add(back_e);
		
		JButton log_e = new JButton("Logout");
		log_e.setIcon(new ImageIcon("C:\\Users\\Acer\\eclipse-workspace\\CourseManagement\\RequiredImages\\logout.png"));
		log_e.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
                // Ask for confirmation
                int result = JOptionPane.showConfirmDialog(null, "Are you sure you want to logout?", "Logout Confirmation",
                        JOptionPane.YES_NO_OPTION);

                if (result == JOptionPane.YES_OPTION) {
                    Main loginFrame = new Main(); 
                    loginFrame.setVisible(true);
                    dispose(); // Close the current frame 
                } else {
                    
                }
            }
        });	
		log_e.setFont(new Font("Arial", Font.PLAIN, 14));
		log_e.setBounds(486, 427, 125, 33);
		contentPane.add(log_e);
	}
}





